-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 04, 2022 at 11:01 AM
-- Server version: 5.7.31
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pizza`
--
CREATE DATABASE IF NOT EXISTS `pizza` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `pizza`;

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
CREATE TABLE IF NOT EXISTS `bookings` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `guest` varchar(80) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `persons` tinyint(4) NOT NULL,
  `message` text,
  `book_status` varchar(10) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `emails`
--

DROP TABLE IF EXISTS `emails`;
CREATE TABLE IF NOT EXISTS `emails` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` varchar(150) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `emails`
--

INSERT INTO `emails` (`id`, `email`, `created_at`, `updated_at`) VALUES
(1, 'coco@gmail.com', '2022-04-04 10:16:39', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
CREATE TABLE IF NOT EXISTS `menus` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `price` float NOT NULL,
  `img` varchar(40) DEFAULT NULL,
  `info` varchar(250) DEFAULT NULL,
  `item_status` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `title`, `price`, `img`, `info`, `item_status`) VALUES
(1, 'American Pizza', 150, 'american_pizza.jpg', 'Turn up the heat with juicy Beef, sliced Onions, Tomatoes and spicy Green Chilies ', 1),
(2, 'Veg Pizza', 95, 'veg_pizza.jpg', 'Mushrooms, Green peppers, Fresh Tomatoes, Onions, Black Olives Loaded on a tomato', 0),
(3, 'Chicken Pizza', 120, 'chicken_pizza.jpg', 'The ultimate mix of Chicken together with Mushrooms, Red Onions, Green Peppers,', 1),
(4, 'Pepperroni Pizza', 150, 'pepperroni_pizza.jpg', 'One of our all time specialties. A meaty feast of Pepperoni, Mushroom , Black Olives, ', 1),
(5, 'Veg Burger', 50, 'veg_burger.jpg', 'Gourmet Vegan Mushroom Burger,  and tofu, nuts, grains, seeds or fungi ', 0),
(6, 'Chicken Burger', 80, 'chicken_burger.jpg', 'American Yellow Cheese, savory flame-grilled Chicken Burger Patty,', 1),
(7, 'Power Burger', 70, 'power_burger.jpg', 'Our MUSHROOM XXL Burger features Swiss cheese on two flame-grilled beef patties, ', 1),
(8, 'Sandwich Burger', 45, 'sandwich_burger.jpg', 'Our famous combination of Beef Pepperoni, Fresh Tomatoes, Mayonnaise', 1),
(9, 'Gulab Jamun', 45, 'gulab_jamun.jpg', 'Buttery soft freshly made bread sticks sprinkled with a cinnamon-sugar blend', 1),
(10, 'Chocholate Moose', 60, 'chocholate_moose.jpg', 'Cool and creamy, our made-to-order Caramel Sundae is prepared with our velvety', 1),
(11, 'Naugat Moose', 60, 'naugat_moose.jpg', 'Caramel Sundae is prepared with our velvety Vanilla Soft Serve, delicious caramel swirl', 1),
(12, 'Belgium Waffle', 45, 'belgium_waffle.jpg', 'Buttery soft freshly made bread sticks sprinkled with a cinnamon-sugar blend', 1),
(13, 'Ice Tea', 35, 'ice_tea.jpg', ' Try our Classic Mojito with the mint and lemon flavour, large and xlarage size', 0),
(14, 'Salad', 45, 'salad_bar.jpg', 'Our King Chicken Salad is a wonderful medley of romaine lettuce, juicy tomatoes', 1),
(15, 'Fire Wings', 60, 'firewings.jpg', 'Served with our special BBQ sauce (Spicy Hot). 1 free slider per customer.', 1),
(16, 'Cappuccino', 41, 'cappuccino.jpg', 'Medio Size, cream instead of milk, using non-dairy milks, and flavoring with cinnamon', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(80) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `user_email`, `password`, `role`, `created_at`, `updated_at`) VALUES
(1, 'Youssef Elaraby', 'admin@coco.com', '$2y$10$fK2nw5tJeQi0R.B1c4d/XOlhIjizmnl5WK02rgADH80ac9AqIV1Ca', 'admin', '2022-04-04 10:35:30', NULL),
(2, 'Zeinat Sedki', 'sales@coco.com', '$2y$10$.WKRgpAnsDk/eCEHC.thFeU042lbljReu6brjhwM5IK5EiCeV3RMi', 'sales', '2022-04-04 10:36:27', NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
